#timing two methods of adding to a list.
#append and concatenate using +

import time


def appendToList(n):
    alist = []
    t0 = time.perf_counter()    
    for i in range(n):
        alist.append(i)
    t1 = time.perf_counter()
    runtime = round((t1 - t0)* 1000,2) 
    print("time to append ",n," items to list ",runtime, "milliseconds")
    
def concatenateList(n):
    alist = []
    t0 = time.perf_counter()    
    for i in range(n):
        alist = alist + [i]
    t1 = time.perf_counter()
    runtime = round((t1 - t0)* 1000,2) 
    print("time to append ",n, " items to list ",runtime, "milliseconds")

#main
k = int(input("How many items do you want to add to your list? "))
appendToList(k)
concatenateList(k)
quit = input()
